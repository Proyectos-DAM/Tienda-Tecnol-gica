package tienda;

import tienda.model.*;
import tienda.service.*;

import java.math.BigDecimal;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private final CatalogoService catalogo;
    private final CompraService compras;
    private final Scanner sc = new Scanner(System.in);

    public Main() {
        JsonStore store = new JsonStore();
        this.catalogo = new CatalogoService(store);
        this.compras = new CompraService(catalogo);
    }

    public static void main(String[] args) {
        new Main().run();
    }

    private void run() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Opción: ");
            switch (opcion) {
                case 1 -> mostrarDatosUsuario();
                case 2 -> mostrarProductosPorCategoria();
                case 3 -> mostrarHistorialCompras();
                case 4 -> comprarProducto();
                case 5 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida.");
            }
            System.out.println();
        } while (opcion != 5);
    }

    private void mostrarMenu() {
        System.out.println("=== Mi Tienda Online ===");
        System.out.println("1) Datos personales del usuario");
        System.out.println("2) Ver productos por categoría");
        System.out.println("3) Ver historial de compras");
        System.out.println("4) Comprar producto");
        System.out.println("5) Salir");
    }

    private void mostrarDatosUsuario() {
        int id = leerEntero("Id de usuario: ");
        Usuario u = catalogo.getUsuarioById(id);
        if (u == null) {
            System.out.println("Usuario no encontrado.");
            return;
        }
        System.out.println("Usuario: " + u.getNombre() + " (" + u.getEmail() + ")");
        Direccion d = u.getDireccion();
        if (d != null) {
            System.out.println("Dirección: " + d);
        }
    }

    private void mostrarProductosPorCategoria() {
        listarCategorias();
        int catId = leerEntero("Id de categoría: ");
        List<Producto> productos = catalogo.getProductosByCategoria(catId);
        if (productos.isEmpty()) {
            System.out.println("Sin productos o categoría inexistente.");
            return;
        }
        productos.forEach(p ->
                System.out.println(p.getId() + " - " + p.getNombre() +
                        " | Precio: " + p.getPrecio() +
                        " | Stock: " + p.getInventario()));
    }

    private void mostrarHistorialCompras() {
        int id = leerEntero("Id de usuario: ");
        Usuario u = catalogo.getUsuarioById(id);
        if (u == null) {
            System.out.println("Usuario no encontrado.");
            return;
        }
        List<Compra> hist = u.getHistorialCompras();
        if (hist == null || hist.isEmpty()) {
            System.out.println("Sin compras registradas.");
            return;
        }
        hist.forEach(c -> System.out.println(
                "Producto " + c.getProductoId() +
                        " | Cantidad: " + c.getCantidad() +
                        " | Fecha: " + c.getFecha()
        ));
    }

    private void comprarProducto() {
        int usuarioId = leerEntero("Id de usuario: ");
        int productoId = leerEntero("Id de producto: ");
        int cantidad = leerEntero("Cantidad: ");
        try {
            BigDecimal total = compras.comprar(usuarioId, productoId, cantidad);
            System.out.println("Compra OK. Total: " + total);
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void listarCategorias() {
        System.out.println("Categorías disponibles:");
        catalogo.getCategorias().forEach(c ->
                System.out.println(c.getId() + " - " + c.getNombre()));
    }

    private int leerEntero(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int v = Integer.parseInt(sc.nextLine().trim());
                return v;
            } catch (NumberFormatException | InputMismatchException e) {
                System.out.println("Introduce un número válido.");
            }
        }
    }
}