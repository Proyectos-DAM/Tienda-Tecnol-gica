package tienda.service;

import tienda.model.Compra;
import tienda.model.Producto;
import tienda.model.Tienda;
import tienda.model.Usuario;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;

public class CompraService {
    private final CatalogoService catalogo;

    public CompraService(CatalogoService catalogo) {
        this.catalogo = catalogo;
    }

    /**
     * Realiza la compra. Actualiza inventario y añade al historial. Persiste en JSON.
     * @return importe total = precio * cantidad
     */
    public BigDecimal comprar(int usuarioId, int productoId, int cantidad) {
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad debe ser > 0");
        Tienda tienda = catalogo.getTienda();

        Usuario u = catalogo.getUsuarioById(usuarioId);
        if (u == null) throw new IllegalArgumentException("Usuario no encontrado: " + usuarioId);

        Producto p = catalogo.getProductoById(productoId);
        if (p == null) throw new IllegalArgumentException("Producto no encontrado: " + productoId);

        if (p.getInventario() < cantidad) {
            throw new IllegalStateException("Stock insuficiente. Disponible: " + p.getInventario());
        }

        // actualizar stock
        p.setInventario(p.getInventario() - cantidad);

        // registrar compra
        if (u.getHistorialCompras() == null) u.setHistorialCompras(new ArrayList<>());
        u.getHistorialCompras().add(new Compra(p.getId(), cantidad, LocalDate.now()));

        // persistir
        catalogo.guardar();

        // total
        BigDecimal precio = p.getPrecio() == null ? BigDecimal.ZERO : p.getPrecio();
        return precio.multiply(BigDecimal.valueOf(cantidad));
    }
}
