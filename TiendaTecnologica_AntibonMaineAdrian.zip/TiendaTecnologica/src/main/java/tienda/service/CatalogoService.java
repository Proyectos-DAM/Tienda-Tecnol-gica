package tienda.service;

import tienda.model.*;

import java.util.*;
import java.util.stream.Collectors;

public class CatalogoService {
    private final JsonStore store;
    private Tienda tienda;

    public CatalogoService(JsonStore store) {
        this.store = store;
        this.tienda = store.load();
        if (this.tienda.getCategorias() == null) this.tienda.setCategorias(new ArrayList<>());
        if (this.tienda.getUsuarios() == null) this.tienda.setUsuarios(new ArrayList<>());
    }

    public Tienda getTienda() { return tienda; }

    public Usuario getUsuarioById(int id) {
        return tienda.getUsuarios().stream()
                .filter(u -> u.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Producto> getProductosByCategoria(int categoriaId) {
        Categoria cat = getCategoriaById(categoriaId);
        return cat == null ? Collections.emptyList() : safeProductos(cat);
    }

    public Producto getProductoById(int productoId) {
        return tienda.getCategorias().stream()
                .flatMap(c -> safeProductos(c).stream())
                .filter(p -> p.getId() == productoId)
                .findFirst()
                .orElse(null);
    }

    public List<Categoria> getCategorias() {
        return tienda.getCategorias();
    }

    public Categoria getCategoriaById(int categoriaId) {
        return tienda.getCategorias().stream()
                .filter(c -> c.getId() == categoriaId)
                .findFirst()
                .orElse(null);
    }

    public List<Producto> buscarProductosPorNombre(String texto) {
        String q = texto == null ? "" : texto.toLowerCase();
        return tienda.getCategorias().stream()
                .flatMap(c -> safeProductos(c).stream())
                .filter(p -> p.getNombre() != null && p.getNombre().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    public void recargarDesdeDisco() {
        this.tienda = store.load();
        if (this.tienda.getCategorias() == null) this.tienda.setCategorias(new ArrayList<>());
        if (this.tienda.getUsuarios() == null) this.tienda.setUsuarios(new ArrayList<>());
    }

    public void guardar() {
        store.save(tienda);
    }

    private List<Producto> safeProductos(Categoria c) {
        if (c.getProductos() == null) c.setProductos(new ArrayList<>());
        return c.getProductos();
    }
}
