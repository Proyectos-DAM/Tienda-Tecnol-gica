package tienda.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import tienda.model.Tienda;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;

public class JsonStore {
    private final ObjectMapper mapper;
    private final Path filePath;

    public JsonStore() {
        this("tienda.json");
    }

    public JsonStore(String resourceName) {
        this.mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .enable(SerializationFeature.INDENT_OUTPUT);

        // Ruta de desarrollo: src/main/resources/tienda.json
        Path devPath = Paths.get("src", "main", "resources", resourceName);
        if (Files.exists(devPath)) {
            this.filePath = devPath.toAbsolutePath();
        } else {
            // Fallback a /data/tienda.json para ejecución fuera del IDE
            Path dataDir = Paths.get("data");
            try { Files.createDirectories(dataDir); } catch (IOException ignored) {}
            this.filePath = dataDir.resolve(resourceName).toAbsolutePath();
        }
    }

    public Tienda load() {
        try {
            if (Files.exists(filePath)) {
                return mapper.readValue(Files.readAllBytes(filePath), Tienda.class);
            }
            // Intentar desde el classpath
            try (InputStream is = getClass().getClassLoader().getResourceAsStream("tienda.json")) {
                if (is != null) return mapper.readValue(is, Tienda.class);
            }
            // Si no existe, devolver tienda vacía
            return new Tienda();
        } catch (IOException e) {
            throw new RuntimeException("Error leyendo JSON: " + filePath, e);
        }
    }

    public void save(Tienda tienda) {
        try {
            byte[] json = mapper.writeValueAsBytes(tienda);
            Files.createDirectories(filePath.getParent());
            Files.write(filePath, json, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Error guardando JSON: " + filePath, e);
        }
    }

    public Path getFilePath() {
        return filePath;
    }
}
