package tienda.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Producto {
    private int id;
    private String nombre;
    private BigDecimal precio;
    private String descripcion;
    private Caracteristicas caracteristicas;
    private int inventario;

    public Producto() {}

    public Producto(int id, String nombre, BigDecimal precio, String descripcion, Caracteristicas caracteristicas, int inventario) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.caracteristicas = caracteristicas;
        this.inventario = inventario;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal precio) { this.precio = precio; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Caracteristicas getCaracteristicas() { return caracteristicas; }
    public void setCaracteristicas(Caracteristicas caracteristicas) { this.caracteristicas = caracteristicas; }

    public int getInventario() { return inventario; }
    public void setInventario(int inventario) { this.inventario = inventario; }

    @Override
    public String toString() {
        return "Producto{id=" + id +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", inventario=" + inventario +
                ", descripcion='" + descripcion + '\'' +
                ", caracteristicas=" + caracteristicas +
                '}';
    }
}
