package tienda.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Caracteristicas {
    private String pantalla;
    private String camara;
    private String bateria;

    public Caracteristicas() {}

    public Caracteristicas(String pantalla, String camara, String bateria) {
        this.pantalla = pantalla;
        this.camara = camara;
        this.bateria = bateria;
    }

    public String getPantalla() { return pantalla; }
    public void setPantalla(String pantalla) { this.pantalla = pantalla; }

    public String getCamara() { return camara; }
    public void setCamara(String camara) { this.camara = camara; }

    public String getBateria() { return bateria; }
    public void setBateria(String bateria) { this.bateria = bateria; }

    @Override
    public String toString() {
        return "Caracteristicas{pantalla='" + pantalla + "', camara='" + camara + "', bateria='" + bateria + "'}";
    }
}
